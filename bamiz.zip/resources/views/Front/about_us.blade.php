@extends('Front.master-main')

@section('titlePage')
    درباره ما بامیز
@endsection

@section('content')

    @livewire('front.about-us')

@endsection
