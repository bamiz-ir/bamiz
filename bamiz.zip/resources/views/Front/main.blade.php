@extends('Front.master-main')

@section('titlePage')
    رزرو میز کافه و رستوران با تورمجازی
@endsection

@section('content')
    @livewire('front.main')
@endsection
