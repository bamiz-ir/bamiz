@extends('Front.master-main')

@section('titlePage')
    تور مجازی و رزرو میز
@endsection

@section('content')

   @livewire('front.center-detail')

@endsection
