@extends('Front.master-main')

@section('titlePage')
    مقالات بامیز
@endsection

@section('content')

    @livewire('front.blogs')

@endsection
