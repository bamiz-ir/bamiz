@extends('Front.master-main')

@section('titlePage')
    گالری تصاویر ارسالی کاربران بامیز
@endsection

@section('content')
    @livewire('front.galleries')
@endsection
