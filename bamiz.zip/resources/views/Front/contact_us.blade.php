@extends('Front.master-main')

@section('titlePage')
    تماس با بامیز
@endsection

@section('content')
    @livewire('front.contact-us')
@endsection
