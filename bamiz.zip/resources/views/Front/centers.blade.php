@extends('Front.master-main')

@section('titlePage')
    کافه و رستوران های بامیز
@endsection

@section('content')
    @livewire('front.centers')
@endsection
