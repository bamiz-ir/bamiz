# laravel-persian-validation

persian(farsi فارسی) validation messages for laravel

### Prerequisites

Laravel :)

### Installing

clone or download zip.

```
cd {your-laravel-directory}/resources/lang
```

and copy `fa` folder and `fa.json` in `lang` 

That's all :)

## Contributing

thank you for help us to improve this repository .
any pull request to `master` repo will be accepted

## Authors

* **Mojtaba Rakhisi** - *Initial work* - [mojtabaRKS](https://github.com/mojtabaRKS)


