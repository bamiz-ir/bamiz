
<?php $__env->startSection('titlePage','افزودن تشفریفات'); ?>
<?php $__env->startSection('Styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.options.form-option' , [

    'titlePage' => 'افزودن تشریفات میزبان',

    ])->html();
} elseif ($_instance->childHasBeenRendered('MSzQVsx')) {
    $componentId = $_instance->getRenderedChildComponentId('MSzQVsx');
    $componentTag = $_instance->getRenderedChildComponentTagName('MSzQVsx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('MSzQVsx');
} else {
    $response = \Livewire\Livewire::mount('admin.options.form-option' , [

    'titlePage' => 'افزودن تشریفات میزبان',

    ]);
    $html = $response->html();
    $_instance->logRenderedChild('MSzQVsx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/Options/create.blade.php ENDPATH**/ ?>