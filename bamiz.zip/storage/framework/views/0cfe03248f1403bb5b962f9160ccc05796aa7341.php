<div class="row">
    <div class="col-xs-12">
        <div class="col-lg-12">
            <div class="card-box">
                <h2 class="card-title"><b><?php echo e($titlePage); ?></b></h2>

                <?php if($errors->any()): ?>

                    <div class="alert alert-danger">

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($e); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>

                <form  class="form-horizontal"
                      action="<?php echo e($type == 'edit' ? route('roles.update' , $role_id) : route('roles.store')); ?>"
                      method="post"
                      enctype="multipart/form-data">

                    <?php if($type == 'edit'): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>

                        <div class="form-group">
                            <label class="control-label col-lg-2">نام مقام</label>
                            <div class="col-md-10">
                                <input wire:model.defer="name" required id="title" type="text" name="name"
                                       class="form-control rounded"
                                       placeholder="نام مقام را وارد کنید" value="<?php echo e($name != null? $name : old('name')); ?>">
                            </div>
                        </div>

                        <div class="form-group">
                            <label class="control-label col-lg-2">دسترسی ها</label>
                            <div class="col-lg-10">
                                <select wire:model.defer="permission_id" required name="permission_id[]"
                                        class="selectpicker form-control" multiple data-live-search="true">
                                    <?php $__currentLoopData = $permissions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option
                                            <?php if(in_array($item->id , $permission_id)): ?> selected  <?php endif; ?>
                                            value="<?php echo e($item->id); ?>">
                                            <?php echo e($item->name); ?> </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </div>
                        </div>

                    <div class="col-lg-12">
                        <div class="m-1-25 m-b-20">
                            <button class="btn btn-info btn-border-radius waves-effect" type="submit">ثبت</button>
                            <a href="<?php echo e(route('roles.index')); ?>"
                               class="btn btn-danger btn-border-radius waves-effect">
                                بازگشت
                            </a>
                        </div>
                    </div>
                </form>

            </div>
        </div>

    </div>
</div>
<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/roles/form-role.blade.php ENDPATH**/ ?>