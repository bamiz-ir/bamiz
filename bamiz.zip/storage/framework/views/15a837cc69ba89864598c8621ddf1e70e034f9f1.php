<div class="row">

    <?php if(session()->has('message')): ?>
        <script>
            Swal.fire({
                title: "تبریک ! 🥳",
                icon: 'success',
                text: '<?php echo e(session('message')); ?>',
                type: "success",
                cancelButtonColor: 'var(--primary)',
                confirmButtonText: 'اوکی',
            })
        </script>

    <?php endif; ?>
    <div class="col-lg-12">
        <div class="card-box">
            <div class="card-block">
                <h4 class="card-title"><?php echo e($titlePage); ?></h4>

                <?php echo $__env->make('livewire.admin.searchBox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>نام کابری</th>
                        <th>نام</th>
                        <th>نام خانوادگی</th>
                        <th>ایمیل</th>
                        <th>وضعیت</th>
                        <th>تلفن</th>
                        <th>نقش</th>
                        <th>عکس</th>
                        <th>تاریخ انتشار</th>
                        <th>اعمال</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->username); ?></td>
                            <td><?php echo e($item->name); ?></td>
                            <td><?php echo e($item->lastName); ?></td>
                            <td><?php echo e($item->email); ?></td>
                            <td>

                                <span class=" <?php if($item->active): ?>

                                <?php echo e("label label-success-border rounded"); ?>


                                <?php else: ?>

                                <?php echo e("label label-danger-border rounded"); ?>


                                <?php endif; ?>">



                                    <?php if($item->active): ?>

                                        فعال

                                    <?php else: ?>

                                        غیر فعال

                                    <?php endif; ?>

                                </span>

                            </td>
                            <td><?php echo e($item->phone); ?></td>
                            <td>

                                <span class=" <?php if($item->level == 'admin'): ?>

                                <?php echo e("label label-success-border rounded"); ?>


                                <?php else: ?>

                                <?php echo e("label label-info-border rounded"); ?>


                                <?php endif; ?>">



                                    <?php if($item->level == 'admin'): ?>

                                        مدیر

                                    <?php else: ?>

                                        کابر

                                    <?php endif; ?>

                                </span>

                            </td>
                            <td><img width="60" src="<?php echo e($item->profile_photo_path ?  \Illuminate\Support\Facades\Storage::url($item->profile_photo_path)  : 'https://www.hardiagedcare.com.au/wp-content/uploads/2019/02/default-avatar-profile-icon-vector-18942381.jpg'); ?>" alt="عکس کابر"> </td>

                            <td><?php echo e(\Hekmatinasser\Verta\Verta:: instance($item->created_at)->format('%B %d، %Y')); ?></td>
                            <td>
                                <div class="buttons ">
                                    <a wire:click="$emit('triggerRestore' , <?php echo e($item->id); ?>)"
                                       class="btn btn-primary btn-action mr-1"
                                       data-toggle="tooltip" title=""
                                       data-original-title="آزاد سازی"><i
                                            class="fas fa-pencil-alt"></i><i
                                            class="fa fa-refresh"> </i> </a>
                                    <button wire:click="$emit('triggerDelete' , <?php echo e($item->id); ?>)"
                                            type="button"
                                            data-original-title="حذف"
                                            data-toggle="tooltip"
                                            class="btn btn-danger btn-action"><i
                                            class="fa fa-trash"> </i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($users->links('livewire.admin.pagination')); ?>


            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('StackScript'); ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {

        window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', orderId => {
            Swal.fire({
                title: "هشدار ! ",
                icon: 'warning',
                text: "آیا می خواهید این کابر حذف شود ؟ 🤔",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#00aced',
                cancelButtonColor: '#e6294b',
                confirmButtonText: 'حذف',
                cancelButtonText: 'انصراف'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                window.livewire.find('<?php echo e($_instance->id); ?>').call('destroy', orderId)
                    // success response
                    Swal.fire({
                        title: session('message'),
                        icon: 'success',
                        type: 'success'
                    });

                }
            });
        });
        })
    </script>

    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {

        window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerRestore', orderId => {
            Swal.fire({
                title: "هشدار ! ",
                icon: 'warning',
                text: "آیا می خواهید این کابر از بلاک خارج شود ؟ 🤔",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#00aced',
                cancelButtonColor: '#e6294b',
                confirmButtonText: 'آزاد سازی',
                cancelButtonText: 'انصراف'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                window.livewire.find('<?php echo e($_instance->id); ?>').call('restore', orderId)
                    // success response
                    Swal.fire({
                        title: session('message'),
                        icon: 'success',
                        type: 'success'
                    });

                }
            });
        });
        })
    </script>
<?php $__env->stopPush(); ?>

<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/block-users/list-block-user.blade.php ENDPATH**/ ?>