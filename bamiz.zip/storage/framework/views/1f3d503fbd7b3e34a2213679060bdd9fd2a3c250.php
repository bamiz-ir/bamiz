<div class="row">

    <?php if(session()->has('message')): ?>
        <script>
            Swal.fire({
                title: "تبریک ! 🥳",
                icon: 'success',
                text: '<?php echo e(session('message')); ?>',
                type: "success",
                cancelButtonColor: 'var(--primary)',
                confirmButtonText: 'اوکی',
            })
        </script>

    <?php endif; ?>
    <div class="col-lg-12">
        <div class="card-box">
            <div class="card-block">
                <h4 class="card-title"><?php echo e($titlePage); ?></h4>

                <?php echo $__env->make('livewire.admin.searchBox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>کلید</th>
                        <th>مقدار</th>
                        <th>تاریخ ثبت</th>
                        <th>اعمال</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $settings; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->key); ?></td>
                            <td><?php echo e(\Illuminate\Support\Str::limit($item->value , 100)); ?></td>
                            <td><?php echo e(\Hekmatinasser\Verta\Verta:: instance($item->created_at)->format('%B %d، %Y')); ?></td>
                            <td>
                                <div class="buttons ">
                                    <a href="<?php echo e(route('settings.edit' , $item->id)); ?>" class="btn btn-primary btn-action mr-1"
                                       data-toggle="tooltip" title=""
                                       data-original-title="ویرایش"><i
                                            class="fas fa-pencil-alt"></i><i
                                            class="fa fa-pencil"> </i> </a>
                                    <button wire:click="$emit('triggerDelete',<?php echo e($item->id); ?>)"
                                            type="button"
                                            data-original-title="حذف"
                                            data-toggle="tooltip"
                                            class="btn btn-danger btn-action"><i
                                            class="fa fa-trash"> </i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>

                    <?php echo e($settings->links('livewire.admin.pagination')); ?>


                </table>
            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('StackScript'); ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {

        window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', orderId => {
            Swal.fire({
                title: "هشدار ! ",
                icon: 'warning',
                text: "آیا می خواهید این تنظیمات حذف شود ؟ 🤔",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#00aced',
                cancelButtonColor: '#e6294b',
                confirmButtonText: 'حذف',
                cancelButtonText: 'انصراف'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                window.livewire.find('<?php echo e($_instance->id); ?>').call('destroy', orderId)
                    // success response
                    Swal.fire({
                        title: session('message'),
                        icon: 'success',
                        type: 'success'
                    });

                }
            });
        });
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/settings/list-setting.blade.php ENDPATH**/ ?>