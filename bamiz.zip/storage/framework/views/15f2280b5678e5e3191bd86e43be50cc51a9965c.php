
<?php $__env->startSection('titlePage','افزودن زمان کاری'); ?>
<?php $__env->startSection('Styles'); ?>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.worktimes.form-worktime',[
    'titlePage' => 'افزودن زمان کاری میزبان',
    ])->html();
} elseif ($_instance->childHasBeenRendered('EjzqtIr')) {
    $componentId = $_instance->getRenderedChildComponentId('EjzqtIr');
    $componentTag = $_instance->getRenderedChildComponentTagName('EjzqtIr');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('EjzqtIr');
} else {
    $response = \Livewire\Livewire::mount('admin.worktimes.form-worktime',[
    'titlePage' => 'افزودن زمان کاری میزبان',
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('EjzqtIr', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/WorkTimes/create.blade.php ENDPATH**/ ?>