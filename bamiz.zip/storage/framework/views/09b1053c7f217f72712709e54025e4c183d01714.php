<?php $__env->startSection('titlePage','افزودن غذا'); ?>
<?php $__env->startSection('Styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("admin.products.form-product" ,[

            'titlePage' => 'افزودن غذا به منو میزبان'

    ])->html();
} elseif ($_instance->childHasBeenRendered('REqaOcg')) {
    $componentId = $_instance->getRenderedChildComponentId('REqaOcg');
    $componentTag = $_instance->getRenderedChildComponentTagName('REqaOcg');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('REqaOcg');
} else {
    $response = \Livewire\Livewire::mount("admin.products.form-product" ,[

            'titlePage' => 'افزودن غذا به منو میزبان'

    ]);
    $html = $response->html();
    $_instance->logRenderedChild('REqaOcg', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/Products/create.blade.php ENDPATH**/ ?>