
<?php $__env->startSection('titlePage','لیست مقالات و اخبار'); ?>
<?php $__env->startSection('Styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("admin.articles.list-article" , [

        'titlePage' => 'لیست مقالات میزبان'

    ])->html();
} elseif ($_instance->childHasBeenRendered('rdK8sNE')) {
    $componentId = $_instance->getRenderedChildComponentId('rdK8sNE');
    $componentTag = $_instance->getRenderedChildComponentTagName('rdK8sNE');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rdK8sNE');
} else {
    $response = \Livewire\Livewire::mount("admin.articles.list-article" , [

        'titlePage' => 'لیست مقالات میزبان'

    ]);
    $html = $response->html();
    $_instance->logRenderedChild('rdK8sNE', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/Articles/main.blade.php ENDPATH**/ ?>
