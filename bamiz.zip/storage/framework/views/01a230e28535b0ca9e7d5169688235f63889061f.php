<div class="row">
    <div class="col-xs-12">
        <div class="col-lg-12">
            <div class="card-box">
                <h2 class="card-title"><b><?php echo e($titlePage); ?></b></h2>

                <?php if($errors->any()): ?>

                    <div class="alert alert-danger">

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($e); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>

                <form class="form-horizontal"
                      action="<?php echo e($type == 'edit' ? route('questions.update' , $question_id) :  route('questions.store')); ?>"
                      method="post"
                      enctype="multipart/form-data">

                    <?php if($type == 'edit'): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="control-label col-lg-2">تیکت</label>
                        <div class="col-md-10">

                            <select required class="form-control rounded" name="ticket_id">

                                <option value="">بدون تیکت</option>

                                <?php $__currentLoopData = $tickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option
                                        <?php echo e($type == 'edit' && $s->id == $question->ticket_id ? 'selected' : old('ticket_id')); ?> value="<?php echo e($s->id); ?>"><?php echo e($s->title); ?></option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>

                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-lg-2">متن پرسش</label>
                        <div class="col-md-10">
                            <textarea required name="text" class="form-control"
                                      rows="5"
                                      placeholder="متن را وارد کنید"><?php echo e($text != null ? $text : old('text')); ?></textarea>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="m-1-25 m-b-20">
                            <button class="btn btn-info btn-border-radius waves-effect" type="submit">ثبت</button>
                            <a href="<?php echo e(route('questions.index')); ?>"
                               class="btn btn-danger btn-border-radius waves-effect">
                                بازگشت
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>



<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/questions/form-question.blade.php ENDPATH**/ ?>