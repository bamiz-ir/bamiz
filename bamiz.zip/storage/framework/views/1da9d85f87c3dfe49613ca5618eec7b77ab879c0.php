<div class="row">
    <div class="col-xs-12">
        <div class="col-lg-12">
            <div class="card-box">
                <h2 class="card-title"><b><?php echo e($titlePage); ?></b></h2>

                <?php if($errors->any()): ?>

                    <div class="alert alert-danger">

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($e); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>

                <form wire:submit.prevent="<?php echo e($type == 'edit'  ?  "edit($option_reserve_id)"  :  "store"); ?>"
                      class="form-horizontal"
                      method="post"
                      enctype="multipart/form-data">

                    <?php if($type == 'edit'): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="control-label col-lg-2">رزرو ها</label>
                        <div class="col-md-10">
                            <select wire:model="reserve_id" required class="form-control rounded" name="reserve_id">

                                <option value="">بدون رزرو</option>

                                <?php $__currentLoopData = $reserves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option
                                        <?php echo e($type == 'edit' && $s->id == $optionReserve->reserve_id ? 'selected' : old('reserve_id')); ?> value="<?php echo e($s->id); ?>"> <?php echo e($s->user->username); ?>

                                        | <?php echo e($s->center->name); ?> </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-lg-2">مراکز</label>
                        <div class="col-md-10">
                            <select wire:model="center_id" required class="form-control rounded" name="center_id">


                                <option value="">بدون مرکز</option>

                                <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option
                                        <?php echo e($type == 'edit' && $s->id == $optionReserve->center_id ? "selected"  : old('center_id')); ?>

                                        value="<?php echo e($s->id); ?>"> <?php echo e($s->name); ?> </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                        </div>
                    </div>

                    <div class="form-group">
                        <label class="control-label col-lg-2">تشریفات</label>
                        <div class="col-md-10">
                            <select wire:model="option_id" required multiple class="form-control" name="option_id[]">

                                <option value="">بدون تشریفات</option>

                                <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option
                                        <?php echo e($type == 'edit' && $s->id == $optionReserve->option_id ? "selected"  : old('option_id')); ?>

                                        value="<?php echo e($s->id); ?>"> <?php echo e($s->title); ?> </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </select>
                        </div>
                    </div>

                    <div class="col-lg-12">
                        <div class="m-1-25 m-b-20">
                            <button class="btn btn-info btn-border-radius waves-effect" type="submit">ثبت</button>
                            <a href="<?php echo e(route('option_reserve.index')); ?>"
                               class="btn btn-danger btn-border-radius waves-effect">
                                بازگشت
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/option-reserves/form-option-reserve.blade.php ENDPATH**/ ?>