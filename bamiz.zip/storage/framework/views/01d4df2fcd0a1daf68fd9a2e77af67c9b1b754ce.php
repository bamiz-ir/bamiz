<div class="row">

    <?php if(session()->has('message')): ?>
        <script>
            Swal.fire({
                title: "تبریک ! 🥳",
                icon: 'success',
                text: '<?php echo e(session('message')); ?>',
                type: "success",
                cancelButtonColor: 'var(--primary)',
                confirmButtonText: 'اوکی',
            })
        </script>

    <?php endif; ?>
    <div class="col-lg-12">
        <div class="card-box">
            <div class="card-block">
                <h4 class="card-title"><?php echo e($titlePage); ?></h4>

                <?php echo $__env->make('livewire.admin.searchBox', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                <table class="table table-hover">
                    <thead>
                    <tr>
                        <th>عنوان</th>
                        <th>قیمت</th>
                        <th>مرکز</th>
                        <th>توضحیات</th>
                        <th>عکس</th>
                        <th>اعمال</th>
                    </tr>
                    </thead>
                    <tbody>

                    <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($item->title); ?></td>
                            <td><?php echo e($item->price); ?></td>
                            <td><?php echo e($item->center->name); ?></td>
                            <td><?php echo e($item->description); ?></td>
                            <td><img width="60" src="<?php echo e($item->images['images']['300']); ?>" alt="عکس تشریفات"> </td>
                            <td><?php echo e(\Hekmatinasser\Verta\Verta:: instance($item->created_at)->format('%B %d، %Y')); ?></td>
                            <td>
                                <div class="buttons ">
                                    <a wire:click="$emit('triggerRestore' , <?php echo e($item->id); ?>)" class="btn btn-primary btn-action mr-1"
                                       data-toggle="tooltip" title=""
                                       data-original-title="بازیابی"><i
                                            class="fas fa-pencil-alt"></i><i
                                            class="fa fa-refresh"> </i> </a>
                                    <button wire:click="$emit('triggerDelete',<?php echo e($item->id); ?>)"
                                            type="button"
                                            data-original-title="حذف"
                                            data-toggle="tooltip"
                                            class="btn btn-danger btn-action"><i
                                            class="fa fa-trash"> </i>
                                    </button>
                                </div>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>

                <?php echo e($options->links('livewire.admin.pagination')); ?>


            </div>
        </div>
    </div>
</div>
<?php $__env->startPush('StackScript'); ?>
    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {

        window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerDelete', orderId => {
            Swal.fire({
                title: "هشدار ! ",
                icon: 'warning',
                text: "آیا می خواهید این تشریفات (برای همیشه) حذف شود ؟ 🤔",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#00aced',
                cancelButtonColor: '#e6294b',
                confirmButtonText: 'حذف',
                cancelButtonText: 'انصراف'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                window.livewire.find('<?php echo e($_instance->id); ?>').call('destroy', orderId)
                    // success response
                    Swal.fire({
                        title: session('message'),
                        icon: 'success',
                        type: 'success'
                    });

                }
            });
        });
        })
    </script>

    <script type="text/javascript">
        document.addEventListener('DOMContentLoaded', function () {

        window.livewire.find('<?php echo e($_instance->id); ?>').on('triggerRestore', orderId => {
            Swal.fire({
                title: "هشدار ! ",
                icon: 'warning',
                text: "آیا می خواهید این تشریفات بازیابی شود ؟ 🤔",
                type: "warning",
                showCancelButton: true,
                confirmButtonColor: '#00aced',
                cancelButtonColor: '#e6294b',
                confirmButtonText: 'بازیابی',
                cancelButtonText: 'انصراف'
            }).then((result) => {
                //if user clicks on delete
                if (result.value) {
                    // calling destroy method to delete
                window.livewire.find('<?php echo e($_instance->id); ?>').call('restore', orderId)
                    // success response
                    Swal.fire({
                        title: session('message'),
                        icon: 'success',
                        type: 'success'
                    });

                }
            });
        });
        })
    </script>
<?php $__env->stopPush(); ?>
<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/trash-options/list-trash-option.blade.php ENDPATH**/ ?>