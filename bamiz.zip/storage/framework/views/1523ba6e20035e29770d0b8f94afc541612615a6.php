<?php $__env->startSection('titlePage','اعطای مقام جدید به کاربر'); ?>
<?php $__env->startSection('Styles'); ?>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/css/bootstrap-select.css" />
<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/2.1.1/jquery.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/bootstrap-select/1.13.1/js/bootstrap-select.min.js"></script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.role-users.form-role-user',[
        'titlePage' => 'اعطای مقام جدید به کاربر بامیز',
    ])->html();
} elseif ($_instance->childHasBeenRendered('5iMSWwt')) {
    $componentId = $_instance->getRenderedChildComponentId('5iMSWwt');
    $componentTag = $_instance->getRenderedChildComponentTagName('5iMSWwt');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('5iMSWwt');
} else {
    $response = \Livewire\Livewire::mount('admin.role-users.form-role-user',[
        'titlePage' => 'اعطای مقام جدید به کاربر بامیز',
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('5iMSWwt', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/RoleUsers/create.blade.php ENDPATH**/ ?>