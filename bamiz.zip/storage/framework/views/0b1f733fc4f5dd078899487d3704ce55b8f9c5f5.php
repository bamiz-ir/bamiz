
<?php $__env->startSection('titlePage','لیست دسته بندی ها'); ?>
<?php $__env->startSection('Styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.categories.list-category',[
    'titlePage' => 'لیست دسته بندی های بامیز',
    ])->html();
} elseif ($_instance->childHasBeenRendered('rJCGF6Y')) {
    $componentId = $_instance->getRenderedChildComponentId('rJCGF6Y');
    $componentTag = $_instance->getRenderedChildComponentTagName('rJCGF6Y');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('rJCGF6Y');
} else {
    $response = \Livewire\Livewire::mount('admin.categories.list-category',[
    'titlePage' => 'لیست دسته بندی های بامیز',
    ]);
    $html = $response->html();
    $_instance->logRenderedChild('rJCGF6Y', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/Categories/main.blade.php ENDPATH**/ ?>
