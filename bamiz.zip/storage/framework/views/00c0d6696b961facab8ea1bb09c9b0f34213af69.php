
<?php $__env->startSection('titlePage','ویرایش گالری'); ?>
<?php $__env->startSection('Styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount("admin.galleries.form-gallery" , [

        'titlePage' => 'ویرایش گالری بامیز',
        'type' => 'edit',
        'gallery' => $gallery

    ])->html();
} elseif ($_instance->childHasBeenRendered('hRH5cFX')) {
    $componentId = $_instance->getRenderedChildComponentId('hRH5cFX');
    $componentTag = $_instance->getRenderedChildComponentTagName('hRH5cFX');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('hRH5cFX');
} else {
    $response = \Livewire\Livewire::mount("admin.galleries.form-gallery" , [

        'titlePage' => 'ویرایش گالری بامیز',
        'type' => 'edit',
        'gallery' => $gallery

    ]);
    $html = $response->html();
    $_instance->logRenderedChild('hRH5cFX', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/Galleries/edit.blade.php ENDPATH**/ ?>