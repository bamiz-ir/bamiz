<?php $__env->startSection('titlePage','لیست مراکز غیر فعال'); ?>
<?php $__env->startSection('Styles'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('Scripts'); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

   <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('admin.trash-centers.list-trash-center' , [

        'titlePage' => 'لیست مراکز غیر فعال بامیز',

   ])->html();
} elseif ($_instance->childHasBeenRendered('0bsl0nK')) {
    $componentId = $_instance->getRenderedChildComponentId('0bsl0nK');
    $componentTag = $_instance->getRenderedChildComponentTagName('0bsl0nK');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0bsl0nK');
} else {
    $response = \Livewire\Livewire::mount('admin.trash-centers.list-trash-center' , [

        'titlePage' => 'لیست مراکز غیر فعال بامیز',

   ]);
    $html = $response->html();
    $_instance->logRenderedChild('0bsl0nK', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Admin.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Admin/TrashCenters/main.blade.php ENDPATH**/ ?>
