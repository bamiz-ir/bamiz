<?php $__env->startSection('titlePage'); ?>
    مقالات بامیز
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('front.blogs')->html();
} elseif ($_instance->childHasBeenRendered('o3eQb7P')) {
    $componentId = $_instance->getRenderedChildComponentId('o3eQb7P');
    $componentTag = $_instance->getRenderedChildComponentTagName('o3eQb7P');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('o3eQb7P');
} else {
    $response = \Livewire\Livewire::mount('front.blogs');
    $html = $response->html();
    $_instance->logRenderedChild('o3eQb7P', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Front.master-main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/Front/blogs.blade.php ENDPATH**/ ?>