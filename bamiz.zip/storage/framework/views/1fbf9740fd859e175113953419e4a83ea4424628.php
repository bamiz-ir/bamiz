<div class="row">
    <div class="col-xs-12">
        <div class="col-lg-12">
            <div class="card-box">
                <h2 class="card-title"><b><?php echo e($titlePage); ?></b></h2>

                <?php if($errors->any()): ?>

                    <div class="alert alert-danger">

                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $e): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php echo e($e); ?><br>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </div>

                <?php endif; ?>

                <form wire:submit.prevent="<?php echo e($type == 'edit'  ?  "edit($chair_reserve_id)"  :  "store"); ?>" class="form-horizontal"
                      method="post"
                      enctype="multipart/form-data">

                    <?php if($type == 'edit'): ?>
                        <?php echo method_field('PATCH'); ?>
                    <?php endif; ?>

                    <?php echo csrf_field(); ?>

                    <div class="form-group">
                        <label class="control-label col-lg-2">میز</label>
                        <div class="col-md-10">
                            <select required class="form-control rounded" name="chair_id">

                                <?php $__currentLoopData = $chairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                    <option <?php echo e($type == 'edit' && $s->id == $chair_reserve->chair_id ? 'selected' : old('chair_id')); ?> value="<?php echo e($s->id); ?>"> <?php echo e($s->number); ?>  |  <?php echo e($s->center->name); ?> </option>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                            </select>
                        </div>
                    </div>


                        <div class="form-group">
                            <label class="control-label col-lg-2">رزرو</label>
                            <div class="col-md-10">
                                <select required class="form-control rounded" name="reserve_id">


                                    <?php $__currentLoopData = $reserves; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                                        <option
                                                value="<?php echo e($s); ?>"> <?php echo e($s); ?> </option>

                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>









                                </select>
                            </div>
                        </div>

                    <div class="col-lg-12">
                        <div class="m-1-25 m-b-20">
                            <button class="btn btn-info btn-border-radius waves-effect" type="submit">ثبت</button>
                            <a href="<?php echo e(route('chair_reserves.index')); ?>"
                               class="btn btn-danger btn-border-radius waves-effect">
                                بازگشت
                            </a>
                        </div>
                    </div>
                </form>
            </div>
        </div>

    </div>
</div>
<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/admin/chair-reserves/form-chair-reserve.blade.php ENDPATH**/ ?>