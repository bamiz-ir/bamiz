<div>

    <div class="container">

        <form class="form-horizontal"
              action="<?php echo e(route('payment')); ?>"
              method="post"
              enctype="multipart/form-data">

            <?php echo csrf_field(); ?>

            <div class="form-group">
                <label class="control-label col-lg-2">مرکز</label>
                <div class="col-md-10">

                    <select wire:model='center_id' required class="form-control rounded" name="center_id">

                        <option value="">بدون مرکز</option>

                        <?php $__currentLoopData = $centers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                <?php echo e($type == 'edit' && $c->id == $reserve->center_id ? "selected" : ""); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->name); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">کاربر</label>
                <div class="col-md-10">

                    <select wire:model.defer="user_id" required class="form-control rounded" name="user_id">

                        <option value="">بدون کاربر</option>

                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option
                                <?php echo e($type == 'edit' && $c->id == $reserve->user_id ? "selected" : ""); ?> value="<?php echo e($c->id); ?>"><?php echo e($c->username); ?></option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>

                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">تاریخ</label>
                <div class="col-md-10">
                    <input required wire:model="date" type="date" name="date"
                           class="form-control rounded"
                           placeholder=" تاریخ را وارد کنید"
                           value="<?php echo e($date != null ? $date : old('date')); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">زمان</label>
                <div class="col-md-10">
                    <select wire:model='time' required class="form-control rounded" name="time">

                        <?php $__currentLoopData = $times; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

                            <option value="<?php echo e($c); ?>">ساعت <?php echo e($c); ?> </option>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">میز ها</label>
                <div class="col-md-10">

                    <select wire:model.defer='chair_id' multiple required class="form-control" name="chair_id[]"
                            multiple data-live-search="true">

                        <?php $__currentLoopData = $chairs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c['id']); ?>"><?php echo e($c['number']); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>
            </div>


            <div class="form-group">
                <label class="control-label col-lg-2">تعداد مهمانان</label>
                <div class="col-md-10">
                    <input required wire:model.defer="guest_count" type="text" name="guest_count"
                           class="form-control rounded"
                           placeholder="تعداد مهمانان را وارد کنید"
                           value="<?php echo e($guest_count != null ? $guest_count : old('guest_count')); ?>">
                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">سفارش غذا ها</label>
                <div class="col-md-10">

                    <select wire:model.defer='product_id' multiple class="form-control" name="product_id[]"
                            multiple data-live-search="true">

                        <option value="0">غذا سفارش نمیدم</option>

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">تشریفات ویژه</label>
                <div class="col-md-10">

                    <select wire:model.defer='option_id' multiple class="form-control" name="option_id[]"
                            multiple data-live-search="true">

                        <option value="0">تشریفاتی ندارم</option>

                        <?php $__currentLoopData = $options; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $c): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($c->id); ?>"><?php echo e($c->title); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                    </select>

                </div>
            </div>

            <div class="form-group">
                <label class="control-label col-lg-2">قیمت رزرو</label>
                <div class="col-md-10">
                    <input required wire:model.defer="price" type="text" readonly name="price"
                           class="form-control rounded"
                           placeholder="قیمت را وارد کنید"
                           value="<?php echo e($price != null ? $price : old('price')); ?>">
                </div>
            </div>


            <div class="col-lg-12">
                <div class="m-1-25 m-b-20">
                    <button class="btn btn-info btn-border-radius waves-effect" type="submit">پرداخت</button>

                </div>
            </div>
        </form>


    </div>


</div>
<?php /**PATH E:\Projects\Bamiz\bamiz\resources\views/livewire/payment.blade.php ENDPATH**/ ?>